/* src/config.h.  Generated from config.h.in by configure.  */
/*==============================================================================
 * FILE: config.h.in
 *
 * PURPOSE: Template file for config.h.  When 'configure' is run, a new
 *   config.h file will be created (overwriting the last).  Currently this
 *   file is empty, but is included to conform to standards, and to enable
 *   future development.
 *============================================================================*/
